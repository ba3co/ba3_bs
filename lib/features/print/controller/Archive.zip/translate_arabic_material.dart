import 'dart:convert';

import 'package:http/http.dart';

Future<String> checkArabicWithTranslate(String data) async {
  bool isArabic = false;

  for (var c in data.codeUnits) {
    if (c >= 0x0600 && c <= 0x06FF) {
      isArabic = true;
      break;
    }
  }

  if (isArabic) {
    String translatedText = await translateText(data, 'ar', 'en');
    return translatedText;
  } else {
    return data;
  }
}

Future<String> translateText(String text, String fromLang, String toLang) async {
  String apiKey = 'AIzaSyAil4Csq27_oCC_BzF7ZMetUEyNM665VqQ'; // استبدل بـ API KEY الخاص بك
  final url = Uri.parse('https://translation.googleapis.com/language/translate/v2?key=$apiKey');

  final response = await post(
    url,
    headers: {
      'Content-Type': 'application/json',
    },
    body: json.encode({
      'q': text,
      'source': fromLang,
      'target': toLang,
      'format': 'text',
    }),
  );

  if (response.statusCode == 200) {
    final jsonResponse = json.decode(response.body);
    String translatedText = jsonResponse['data']['translations'][0]['translatedText'];
    return translatedText;
  } else {
    throw Exception('Failed to translate text');
  }
}
